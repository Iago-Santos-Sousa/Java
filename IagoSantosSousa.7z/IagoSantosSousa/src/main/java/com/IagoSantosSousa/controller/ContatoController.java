package com.IagoSantosSousa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.IagoSantosSousa.model.Contato;
import com.IagoSantosSousa.repository.ContatoRepository;
import com.IagoSantosSousa.service.ServiceContato;

@Controller
public class ContatoController {

	@Autowired
	private ContatoRepository contatoRepository;

	@Autowired
	private ServiceContato serviceContato;

	@GetMapping("/inserirContato")
	public ModelAndView inserirContato() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("contato", new Contato());
		mv.setViewName("Contato/inserirContato");
		return mv;
	}

	@PostMapping("/salvarContato")
	public ModelAndView contato(Contato contato) {
		ModelAndView mv = new ModelAndView();

		// Verificar se algum campo está vazio
		if (contato.getNome().isEmpty() || contato.getTelefone().isEmpty() || contato.getEmail().isEmpty()
				|| contato.getAdicionais().isEmpty()) {
			// Se algum campo estiver vazio, redirecione de volta com uma mensagem de erro
			mv.addObject("error", "Por favor, preencha todos os campos.");
			mv.addObject("contato", contato); // para manter os dados preenchidos
			mv.setViewName("Contato/inserirContato");
			return mv;
		}

		contatoRepository.save(contato);
		// Redirecione para a página de inserção de contato após salvar
		mv.setViewName("redirect:/inserirContato");
		
		return mv;
	}

	@GetMapping("/listarContatos")
	public ModelAndView listarContatos() {
		ModelAndView mv = new ModelAndView();
		java.util.List<Contato> contatos = contatoRepository.findAllContatosById();
		// Verifica se a lista está vazia
		if (contatos.isEmpty()) {
			mv.addObject("message", "Nenhum contato encontrado.");
		} else {
			mv.addObject("contatos", contatos);
		}
		mv.setViewName("Contato/listarContatos");
		return mv;
	}
	
	/*@PostMapping("/alterar")
	public ModelAndView alterarContatoAtt(Contato contato) {
		ModelAndView mv = new ModelAndView();
		String out = serviceContato.alterarContato(contato, contato.getId());
		if (out != null) {
			mv.addObject("msg", out);
			mv.addObject("contato", contato);
			mv.setViewName("Contato/alterar");
		} else {
			mv.setViewName("redirect:/listarContatos");
		}
		return mv;
	}*/

	@GetMapping("/alterar/{id}")
	public ModelAndView alterarContato(@PathVariable("id") Long id) {
		ModelAndView mv = new ModelAndView();
		Contato contato = contatoRepository.findById(id).get();
		mv.addObject("contato", contato);
		mv.setViewName("Contato/alterar");
		return mv;
	}

	@PostMapping("/alterar")
	public ModelAndView alterarContatoAtt(Contato contato) {
		ModelAndView mv = new ModelAndView();

		// Verificar se algum campo está vazio
		if (contato.getNome().isEmpty() || contato.getTelefone().isEmpty() || contato.getEmail().isEmpty()
				|| contato.getAdicionais().isEmpty()) {
			mv.addObject("error", "Por favor, preencha todos os campos.");
			mv.addObject("contato", contato); // para manter os dados preenchidos
			mv.setViewName("Contato/alterar");
			return mv;
		}

		// Salvar o contato no repositório
		contatoRepository.save(contato);
		mv.setViewName("redirect:/listarContatos");
		return mv;
	}

	@GetMapping("/excluir/{id}")
	public ModelAndView excluirContato(@PathVariable("id") Long id) {
		ModelAndView mv = new ModelAndView();
		contatoRepository.deleteById(id);
		mv.setViewName("redirect:/listarContatos");
		return mv;
	}

}
