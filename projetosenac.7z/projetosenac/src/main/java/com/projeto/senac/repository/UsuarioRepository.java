package com.projeto.senac.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.projeto.senac.model.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, Long> {
	@Query("SELECT i FROM Usuario i WHERE i.login = :login and i.senha= :senha")
	public Usuario buscarLogin(String login, String senha);

	public Object findByEmail(String email);

}

