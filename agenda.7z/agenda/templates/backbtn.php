<div id="back-link-container">
    <a href="<?=$BASE_URL?>/index.php" id="back-link">Voltar</a>
</div>
