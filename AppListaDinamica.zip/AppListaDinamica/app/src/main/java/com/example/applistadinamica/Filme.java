package com.example.applistadinamica;

public class Filme {

    private String tituloFilme;
    private String anoFilme;
    private String generoFilme;

    public Filme(String titulo, String genero, String ano){
            this.tituloFilme= titulo;
            this.anoFilme= ano;
            this.generoFilme= genero;
    }// fim construtor

    public String getTituloFilme() {
        return tituloFilme;
    }

    public void setTituloFilme(String tituloFilme) {
        this.tituloFilme = tituloFilme;
    }

    public String getAnoFilme() {
        return anoFilme;
    }

    public void setAnoFilme(String anoFilme) {
        this.anoFilme = anoFilme;
    }

    public String getGeneroFilme() {
        return generoFilme;
    }

    public void setGeneroFilme(String generoFilme) {
        this.generoFilme = generoFilme;
    }
}//fim classe Filme
