package com.projeto.senac.exceptions;

public class ServiceExc extends Exception {
	private static final long serialVersionUID = 1L;

	public ServiceExc(String msg) {
		super(msg);
	}
}
