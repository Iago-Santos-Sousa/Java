<?php
    // include_once("../config/processamento.php");
    include_once("./header.php");
    // include_once("../config/conexao.php");
?>
   
    <div class="container">
        <h1 id="main-title">Minha Agenda</h1>
        <?php if(count($AllContatos) > 0):?>
            <p>Há contatos</p>

            <?php else:?>
                <p id="empty-list-text">Não há contatos 
                    <a href="<?= $BASE_URL?>/create.php">Adicionar contato</a>
                </p>

                <?php endif;?>
    </div>

    

<?php

    include_once("./footer.php");
?>