package com.IagoSantosSousa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.IagoSantosSousa.model.Contato;
import com.IagoSantosSousa.repository.ContatoRepository;
import java.time.LocalDate;

import javax.transaction.Transactional;

@Service
public class ServiceContato {
	@Autowired
	ContatoRepository contatoRepository;

	public void salvarContato(Contato contato) {
		contatoRepository.save(contato);
		// return null;
	}

	public String alterarContato(Contato contato, Long id) {
		contatoRepository.save(contato);
		return null;
	}
}
