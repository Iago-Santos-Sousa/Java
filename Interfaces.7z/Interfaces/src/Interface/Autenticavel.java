package Interface;

public interface Autenticavel {
    public boolean autentica(String Senha);
}
