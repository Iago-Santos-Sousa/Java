package com.example.applistadinamica;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Filme> listarFilmes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerIdView);
        this.criarFilmes();
        adapter adp = new adapter((this.listarFilmes));
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(
                getApplicationContext()
        );
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adp);

    }// fim onCreate

    public void criarFilmes(){
        Filme filme = new Filme("O Homem Aranha", "ação", "2010");
        /*

        */
        filme = new Filme("Mulher maravilha", "ação", "2018");
        filme = new Filme("Capitão américa", "ação", "2016");
        filme = new Filme("A lenda", "drama", "2011");
        filme = new Filme("Gladiador", "ação", "2000");
        listarFilmes.add(filme);
    }// fim criarFilmes


}