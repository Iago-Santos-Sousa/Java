package Loopings;

public class livroDeNotasTeste {

    public static void main(String[] args) {
        LivroDeNotas obj = new LivroDeNotas();
        obj.inputNota(5);

    }
}
