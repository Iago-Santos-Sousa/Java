package Interface;

public interface AreaCalculavel {

    double calculaArea();
}
