package com.projeto.IagoSantosSousa.repository;

import org.springframework.data.repository.CrudRepository;
import com.projeto.IagoSantosSousa.model.Usuario;
public interface UsuarioRepository extends CrudRepository<Usuario, Long>{
}
