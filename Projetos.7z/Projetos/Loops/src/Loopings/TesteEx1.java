package Loopings;

public class TesteEx1 {

    public static void main(String args[]) {
        Ex1 obj = new Ex1();
        int resultado = obj.efetuaSomaImpar();
        System.out.println("Total dos ímpares: " + resultado);
    }
}
