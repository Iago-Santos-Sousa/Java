package com.example.mylistapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class MainActivity extends AppCompatActivity {

    private ListView List;
    private String [] itens={
            "Hugo Chaves",
            "Aline Alves",
            "Pietra Mendes",
            "Paulo César",
            "Marcelo Meneses"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.List= findViewById(R.id.List);
        ArrayAdapter<String> adapter= new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1, itens
        );
        List.setAdapter(adapter);
    }
}