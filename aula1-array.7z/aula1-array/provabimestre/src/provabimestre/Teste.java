package provabimestre;

public class Teste {

	public static void main(String[] args) {

		IntArray obj = new IntArray();
		obj.arrayTeste();
		System.out.println();
		obj.mais();
	
	}
}
