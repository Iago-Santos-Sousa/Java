package com.IagoSantosSousa.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.IagoSantosSousa.model.Contato;

import antlr.collections.List;

public interface ContatoRepository extends CrudRepository<Contato, Long> {

	@Query("SELECT c FROM Contato c ORDER BY c.id")
	public java.util.List<Contato> findAllContatosById();

}
