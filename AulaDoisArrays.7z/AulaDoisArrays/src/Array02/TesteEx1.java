package Array02;

import java.util.Random;

public class TesteEx1 {
	
public static void main(String[] args) {
		
		Ex1 obj = new Ex1();
		obj.posicoes();
		obj.modifica();
	}
}
