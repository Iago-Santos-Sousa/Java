<?php
 
    include_once("conexao.php");
    include_once("url.php");

    $id;

    if(!empty($_GET)){
        $id= $_GET["id"];
    }

    if(!empty($id))
    {
        $query= "SELECT * FROM contatos WHERE id= :id";
        $stmt= $conn->prepare($query);
        $stmt->bindParam(":id",$id);
        $stmt->execute();
        $onlyContato= $stmt->fetch();// retorna apenas a linha referente ao id
    }

    else
    {
        $query= "SELECT * FROM contatos";
        $stmt= $conn->prepare($query);
        $stmt->execute();
        $AllContatos=[];
        $AllContatos= $stmt->fetchAll();// retorna todas as linhas para a variavel
    }



?>