package com.IagoSantosSousa.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.IagoSantosSousa.model.Contato;

@RestController
public class IndexController {
	@GetMapping("/")
	public ModelAndView index() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("contato", new Contato());
		mv.setViewName("Contato/inserirContato");
		return mv;
	}
}
