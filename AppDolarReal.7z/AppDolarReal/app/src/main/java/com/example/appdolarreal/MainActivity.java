package com.example.appdolarreal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    protected EditText editValorDolar, editQuantDolar;
    protected TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }// onCreate

    public void  calcular(View view){
        editValorDolar = findViewById(R.id.editTextIdDolar);
        editQuantDolar = findViewById(R.id.editTextIdQtdDolar);
        textResultado = findViewById(R.id.editTextIdQtdDolar);
        double valorDolar = Double.parseDouble((editValorDolar.getText().toString()));
        double qtdDolar = Double.parseDouble((editValorDolar.getText().toString()));
        double resultado = valorDolar * qtdDolar;
        textResultado.setText("R$"+resultado);

    }
}