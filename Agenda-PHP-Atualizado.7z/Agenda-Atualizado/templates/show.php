<?php
    include_once("header.php");
?>
    <div class="container" id="view-contact-container">
        <h1 id="main-title"> <?= $onlyContato["nome"]?></h1>
    </div>

<?php
    include_once("footer.php");
?>
